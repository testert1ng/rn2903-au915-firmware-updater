Requires Java 8

10/30/2015	-	LoRa Development Utility; Beta Build
				- Intended only for use with RN Modules. Some features disabled; or may not reflect expected behavior.